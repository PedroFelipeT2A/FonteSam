<?php
// Como configurar seu modulo:
//
// Acesse admin do WHMCS e clique em Servidores no menu correspondente
// Cadastre/Edite o servidor desejado definindo um nome para ele no campo Name
// no campo Hostname voce colocar a URL do painel incluindo o http:// no inicio
// no campo IP Address voce deve colocar a chave API obtida no painel de controle
// Neste arquivo voce nao deve modificar nada para que nao ocorram erros
  
  function stmvideoadvance_configoptions ()
  {
    $configarray = array ('Espectadores' => array ('Type' => 'text', 'Size' => '10', 'Description' => '<br>(Numero maximo de espectadores. Ex.: 100)'),
						  'Bitrate' => array ('Type' => 'text', 'Size' => '10', 'Description' => '<br>(Verifique limite de seu plano)'),
						  'Espaco FTP' => array ('Type' => 'text', 'Size' => '10', 'Description' => '<br>(Espaco para FTP, valor em megabytes. Ex.: 1000)'),
						  'Idioma' => array ('Type' => 'dropdown', 'Options' => 'pt-br,en-us,es', 'Description' => '<br>(Idioma Painel - Portugues/English/Espanol)'),
						  'Aplicacao' => array ('Type' => 'dropdown', 'Options' => 'live,tvstation,vod,ipcamera', 'Description' => '<br>(Live - Somente ao vivo | TvStation - ao vivo e ondemand/playlist | VOD - ondemand | IP Camera)')
						 );
    return $configarray;
  }
  
  function stmvideoadvance_adminlink ($params)
  {
	
    $code = '<input type="button" value="Acessar Painel" onclick="window.location = \''.$params['serverhostname'].'/admin\';">';
    return $code;
  }

  function stmvideoadvance_createaccount ($params)
  {
    global $debug;
	
    $query3 = 'SELECT * FROM tblhostingconfigoptions WHERE relid=\'' . $params['accountid'] . '\'';
    $result3 = mysql_query ($query3);
    while ($data3 = mysql_fetch_array ($result3))
    {
      $optionid = $data3['optionid'];
      $configid = $data3['configid'];
      $query2 = '' . 'SELECT * FROM tblproductconfigoptions WHERE id=\'' . $configid . '\'';
      $result2 = mysql_query ($query2);
      $data2 = mysql_fetch_array ($result2);
      $optionname = $data2['optionname'];
      $query2 = '' . 'SELECT * FROM tblproductconfigoptionssub WHERE id=\'' . $optionid . '\'';
      $result2 = mysql_query ($query2);
      $data2 = mysql_fetch_array ($result2);
      $optionvalue = $data2['optionname'];
      $optionvalue = trim ($optionvalue);

      if ($optionname == 'Espectadores') {
        $params['configoption1'] = $optionvalue;
        continue;
      } else {
	  	if ($optionname == 'Bitrate') {
        $params['configoption2'] = $optionvalue;
        continue;
      	} else {
		  if ($optionname == 'Espaco FTP') {
          $params['configoption3'] = $optionvalue;
          continue;
      	  } else {
		    if ($optionname == 'Aplicacao') {
      	    $params['configoption4'] = $optionvalue;
        	continue;
      	    } else {
			  if ($optionname == 'Idioma') {
        	  $params['configoption5'] = $optionvalue;
	          continue;
			  }
			}
		  }
		}
        continue;
      }
    }
	
	$login = str_replace(" ","",$params['clientsdetails']['firstname']);
	$login = $login.mt_rand(1000,9999);
	$login = strtolower($login);

    $api['acao'] = 'cadastrar';
    $api['login'] = $login;
	$api['espectadores'] = $params['configoption1'];
    $api['bitrate'] = $params['configoption2'];
    $api['espaco'] = $params['configoption3'];
    $api['senha'] = $params['password'];
	$api['aplicacao'] = $params['configoption4'];
	$api['idioma'] = $params['configoption5'];
	$api['identificacao'] = urlencode($params['clientsdetails']['firstname']." ".$params['clientsdetails']['lastname']);
	$api['email'] = $params['clientsdetails']['email'];
	
    $response = api_stmvideoadvance ($params['serverhostname'],$params['serverip'],$api);
	
    if ($response['command'] == 'success')
    {

	  mysql_query ('UPDATE tblhosting SET username=\'' . $login . '\',
												password=\'' . encrypt ($api['senha']). '\',
												domain=\'' . $response['returned'] . '\'
											WHERE id=\'' . $params['serviceid'] . '\'');
										
      return 'success';

    }

    return $response['returned'];
  }

  function stmvideoadvance_terminateaccount ($params)
  {
    global $debug;
	
    $LoginBaseQuery = mysql_query ('SELECT 	username FROM tblhosting WHERE id=\'' . $params['serviceid'] . '\'');

    $LoginBase = mysql_fetch_array($LoginBaseQuery);
    $api['acao'] = 'remover';
    $api['login'] = $LoginBase["username"];
	
    $response = api_stmvideoadvance ($params['serverhostname'],$params['serverip'],$api);
	
    if ($response['command'] == 'success')
    {
	  
	  mysql_query ('UPDATE tblhosting 	SET	username=\'\',
												domain=\'\'
											WHERE id=\'' . $params['serviceid'] . '\'');
											
      return 'success';
    }

    return $response['error'];
  }

  function stmvideoadvance_suspendaccount ($params)
  {
    global $debug;
	
    $LoginBaseQuery = mysql_query ('SELECT 	username FROM tblhosting WHERE id=\'' . $params['serviceid'] . '\'');

    $LoginBase = mysql_fetch_array($LoginBaseQuery);
    $api['acao'] = 'bloquear';
    $api['login'] = $LoginBase["username"];

    $response = api_stmvideoadvance ($params['serverhostname'],$params['serverip'],$api);
	
    if ($response['command'] == 'success')
    {
      return 'success';
    }

    return $response['error'];
  }

  function stmvideoadvance_unsuspendaccount ($params)
  {
    global $debug;
	
    $LoginBaseQuery = mysql_query ('SELECT 	username FROM tblhosting WHERE id=\'' . $params['serviceid'] . '\'');

    $LoginBase = mysql_fetch_array($LoginBaseQuery);
    $api['acao'] = 'desbloquear';
    $api['login'] = $LoginBase["username"];
	
    $response = api_stmvideoadvance ($params['serverhostname'],$params['serverip'],$api);
	
    if ($response['command'] == 'success')
    {
      return 'success';
    }

    return $response['error'];
  }

  function api_stmvideoadvance ($serverhostname,$serverip,$api)
  {
	
    $requisicao = '';
    foreach ($api as $option => $setting)
    {
      if (is_array ($setting))
      {
        $setting = serialize ($setting);
      }

      $requisicao .= $setting."/";
    }
	
	$url_requisicao = "".$serverhostname."/admin/api/".$serverip."/".$requisicao."";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url_requisicao);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Modulo Streaming Video WHMCS 1.2 ('.$_SERVER['HTTP_HOST'].')');
	$resultado = curl_exec($ch);
	curl_close($ch);

	if($resultado === false) {
      return array ('command' => 'failed', 'error' => 'N�o foi poss�vel se conectar ao painel de controle.');
	} else {

    list ($status, $msg) = explode ('|', $resultado);
	
    if ($status == '0' || $status == '')
    {
      return array ('command' => 'failed', 'error' => ''.$msg.'');
    }

    return array ('command' => 'success', 'returned' => ''.$msg.'');
	
	}
  }
  


?>